var socket = io();

function readURL(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    console.log(reader);
    reader.onload = function (e) {
      $('[image-preview]')
        .attr('src', e.target.result).attr('name', input.files[0].name);
    };
    reader.readAsDataURL(input.files[0]);
  }
}
$( document ).ready(function() {
  var entries = [];
  var imageEntry = [];
  var folder = $('[detail-folder]');
  $('[detail-folder]').remove();
  $('[single-detail]').remove();
  $('[folder-detail]').remove();
  $('[detail-folder-item]').remove();
  var gallaryItem = $('[gallery-item]');
  var folderItem = $('[folder-data]');
  var obj = $('[drop-area]');
  $('body').on('click', '[add-form]' , function () {
    var addContainer = $('[user-form]');
    var userId = Math.floor(Math.random() * 20);
    var userName = addContainer.find('[username]').val();
    var image = addContainer.find('[image-preview]');
    var userGender = addContainer.find('[gender]:checked').val();
    var userHobby = [];
    addContainer.find('[hobby]:checked').each(function () {
      userHobby.push($(this).val());
    });
    var userCity = addContainer.find('[city] option:selected').val();
    var entry = {
      "uId": userId,
      image : {
        src: image.attr('src'),
        name: image.attr('name')
      },
      "username":  userName,
      "gender":  userGender,
      "hobby":  userHobby,
      "city":  userCity
    };
    socket.emit("sales:add:data", entry, function (response) {
      setTimeout(function (e) {
        console.log(response)
      }, 1000)
    }, function (err) {
      showNotification("Something went wrong. Please try again later.", "error");
    });
    // $.ajax({
    //   type : "POST",
    //   contentType : "application/json",
    //   url : window.location + "api/users/save",
    //   data : JSON.stringify(entry),
    //   dataType : 'json',
    //   success : function(user) {
    //   	console.log("data", user);
    //     alert('successfully added Entry');
    //   },
    //   error : function(e) {
    //     alert("Error!");
    //     console.log("ERROR: ", e);
    //   }
    // });
    clearField();
  });
  function clearField() {
    $(':input' , '[user-form]' )
      .not (':button' , ':reset' , ':submit')
      .prop('checked' , false)
      .prop('selected' , false)
      .not(':checkbox, :radio, select')
      .val('');
    $('[image-preview]').attr('src' , 'http://placehold.it/180');
  }
	// SUBMIT FORM
  $('body').on('click', '[update-btn]' , function () {
    var addContainer = $('[user-form]');
    $('[add-form]').show();
    $('[update-btn]').hide();
    var uId = addContainer.find('[username]').attr('username');
    var userName = addContainer.find('[username]').val();
    var image = addContainer.find('[image-preview]');
    var userGender = addContainer.find('[gender]:checked').val();
    var userHobby = [];
    addContainer.find('[hobby]:checked').each(function () {
      userHobby.push($(this).val());
    });
    var userCity = addContainer.find('[city]:selected').val();
    image.attr('src') && image.attr('name');
    var entry = {
      uid :uId,
      image : {
        name: image.attr('name'),
        src: image.attr('src')
      },
      username : userName,
      gender : userGender,
      hobby : userHobby,
      city : userCity
    };
    $.ajax({
      type : "POST",
      contentType : "application/json",
      url : window.location + "api/users/update",
      data : JSON.stringify(entry),
      dataType : 'json',
      success : function(user) {
        entries = user;
        console.log(entries);
        alert('successfully updated Entry');
        refreshTable();
        location.reload();
      },
      error : function(e) {
        alert("Error!");
        console.log("ERROR: ", e);
      }
    });
  });
  function refreshTable() {
    $('[list-detail]').html('');
    for(var i=0; i < entries.length; i++){
      var entry = entries[i];
      var entryTamplate = templateAdd.clone();
      if(entry.image && entry.image.name)entryTamplate.find('[user-pro]').text(entry.image.name);
      entryTamplate.find('[user-name]').text(entry.username);
      entryTamplate.find('[user-gender]').text(entry.gender);
      entryTamplate.find('[user-hobby]').text(entry.hobby);
      entryTamplate.find('[user-city]').text(entry.city);
      entryTamplate.find('[u-id]').text(entry.uId);
      entryTamplate.find('[delete-btn]').attr('delete-btn' , entry.uId);
      if(entry.image && entry.image.src)entryTamplate.find('[user-pro1]').text(entry.image.src);
      $('[list-detail]').append(entryTamplate);
    }
  }

  obj.on('dragover',function (e) {
    e.stopPropagation();
    e.preventDefault();
    $(this).css('border',"2px solid #16a085");
  });
  obj.on('drop',function (e) {
    $(this).css('border',"2px solid #16a085");
    var dataTransfer = e.originalEvent.dataTransfer;
    if(dataTransfer && dataTransfer.files.length) {
      e.preventDefault();
      e.stopPropagation();
      $.each(dataTransfer.files, function(i, file) {
        var reader = new FileReader();
        var rendomId = Math.floor(Math.random() * 20);
        reader.onload = $.proxy(function(file, gallaryItem, folderItem, event) {
          console.log(file.name)
          var ele = file.type.match('image.*') ? "<img src='" + event.target.result + "' name='" + file.name + "' /> <button class='btn-close' img-attr ='"+ rendomId +"'><i class='fa fa-close'></i></button> " : file.type.match('video.*') ? "<video controls><source src='" + event.target.result + "' name='" + file.name + "'> </video> <button class='btn-close' img-attr ='"+ rendomId +"'><i class='fa fa-close'></i></button> " : "";
          gallaryItem.prepend( $("<li class ='draggable'  li-attr ='"+ rendomId +"'>").append( ele ) );
          var entry = {
            "uId": rendomId,
            "src": event.target.result,
            "name": file.name
          };
          imageEntry.push(entry);
        }, this, file, gallaryItem , folderItem );
        var entry = imageEntry;
        reader.readAsDataURL(file);
        $.ajax({
          type : "POST",
          contentType : "application/json",
          url : window.location + "api/media/add",
          data : JSON.stringify(entry),
          dataType : 'json',
          success : function(user) {
            console.log("data", user);
            alert('successfully added Entry');
          },
          error : function(e) {
            alert("Error!");
            console.log("ERROR: ", e);
          }
        });
        entries.push(entry);
      });
    }
  });
});