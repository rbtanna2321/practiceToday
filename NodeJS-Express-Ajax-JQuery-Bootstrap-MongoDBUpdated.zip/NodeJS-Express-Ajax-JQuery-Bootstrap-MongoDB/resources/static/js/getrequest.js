$( document ).ready(function() {
  var resultArray = [];
  var templateAdd = $('[single-detail]').clone();
  $('[single-detail]').remove();
  var entries = []
  $.ajax({
    type : "GET",
    url : "/api/users/all",
    success: function(result){
      entries = result;
      refreshTable();
      console.log("Success: ", entries);
    },
    error : function(e) {
      $("#getResultDiv").html("<strong>Error</strong>");
      console.log("ERROR: ", e);
    }
  });

  $('body').on('keyup', '[search-entries]' , function () {
    var tempArray = [];
    if($(this).val() && $(this).val().length > 0){
      var matchValue= $(this).val().toLowerCase();
      $.ajax({
        method : "GET",
        url : "/api/users/search",
        data : {username:matchValue},
        success: function(result){
         tempArray = result;
          console.log("Success src: ", tempArray);
          refreshTable(tempArray);
        },
        error : function(e) {
          $("#getResultDiv").html("<strong>Error</strong>");
          console.log("ERROR: ", e);
        }
      });
    }
    else {
      refreshTable();
    }
  });
function refreshTable(tempArray) {
  var arr;
  arr= entries;
  if(tempArray) arr = tempArray;
  console.log(arr);
  $('[list-detail]').html('');
  for(var i=0; i < arr.length; i++){
    var entry = arr[i];
    var entryTamplate = templateAdd.clone();
    if(entry.image && entry.image.name)entryTamplate.find('[user-pro]').text(entry.image.name);
    entryTamplate.find('[user-name]').text(entry.username);
    entryTamplate.find('[user-gender]').text(entry.gender);
    entryTamplate.find('[user-hobby]').text(entry.hobby);
    entryTamplate.find('[user-city]').text(entry.city);
    entryTamplate.find('[u-id]').text(entry.uId);
    entryTamplate.find('[delete-btn]').attr('delete-btn' , entry.uId);
    if(entry.image && entry.image.src)entryTamplate.find('[user-pro1]').text(entry.image.src);
    $('[list-detail]').append(entryTamplate);
  }
}
  $('body').on('click', '[edit-form]' , function () {
    $('[update-btn]').show();
    $('[add-form]').hide();
    var parent = $(this).parent('tr');
    var userId = parent.find('[u-id]').text();
    $.ajax({
      method: "GET",
      url: "/api/users/edit/",
      data: {
        uId:userId
      },
      success: function(result){
        resultArray = result[0];
        editable();
        console.log("Success: ", result);
      },
      error : function(e) {
        $("#getResultDiv").html("<strong>Error</strong>");
        console.log("ERROR: ", e);
      }
  });
  });
function editable() {
  console.log(resultArray)
  var addContainer = $('[user-form]');
  addContainer.find('[image-preview]').attr('src' , resultArray.image.src).attr('name' , resultArray.image.name);
  addContainer.find('[username]').attr('username' , resultArray.uId);
  addContainer.find('[img-dlt]').attr('img-dlt' , resultArray.uId);
  addContainer.find('[username]').val(resultArray.username);
  addContainer.find('[gender][value = "'+ resultArray.gender +'"]').prop('checked' , true);
  var commaSaprate = resultArray.hobby.toString().split(',');
  for(var i = 0; i < commaSaprate.length; i++){
    addContainer.find('[hobby][value = "'+ commaSaprate[i] +'"]').prop('checked' , true);
  }
  addContainer.find('[city]').val(resultArray.city).prop('selected' , 'true');
}
  $('body').on('click', '[delete-btn]' , function () {
      var matchId = $(this).attr('delete-btn');
      $.ajax({
        method: "GET",
        url: "/api/users/delete/",
        data: {
          uId:matchId
        },
        success: function(result){
          resultArray = result[0];
          editable();
          alert('successfully Deleted Entry');
          console.log("Success: ", result);
          location.reload();
        },
        error : function(e) {
          $("#getResultDiv").html("<strong>Error</strong>");
          console.log("ERROR: ", e);
        }
      });
  });
  $('body').on('click', '[img-dlt]' , function () {
    var addContainer = $('[user-form]');
    var imageDelete = addContainer.find('[image-preview]');
    console.log(imageDelete);
    imageDelete = {
      src : imageDelete.attr('src' , 'http://placehold.it/180' ),
      name : imageDelete.attr('name', '')
    };
  });
});