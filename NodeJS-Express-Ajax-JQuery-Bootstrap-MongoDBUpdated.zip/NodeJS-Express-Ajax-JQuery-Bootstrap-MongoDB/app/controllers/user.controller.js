
var User = require('../models/user.model.js');


// Save FormData - User to MongoDB
exports.save = (req, res) => {
	console.log('Post a User: ' + JSON.stringify(req.body));
    // Create a Customer
    var user = new User({
    uId: req.body.uId,
		image: {
      src:  req.body.image.src,
      name: req.body.image.name
    },
      username: req.body.username,
      gender: req.body.gender,
      hobby: req.body.hobby,
      city: req.body.city
    });
    // Save a Customer in the MongoDB
    user.save()
    .then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            message: err.message
        });
    });
};
// Fetch all Users
exports.findAll = (req, res) =>  {
	console.log("Fetch all Users");
    User.find()
    .then(users => {
        res.send(users);
    }).catch(err => {
        res.status(500).send({
            message: err.message
        });
    });
};

// Fetch search Users
exports.search = (req, res) =>  {
  console.log("Fetch search Users", req.query.username);
  var match = req.query.username;
  User.find({username : {$regex:match}})
    .then(users =>{
    res.send(users);
}).catch(err => {
    res.status(500).send({
    message: err.message
  });
});
};

exports.edit = (req , res) =>  {
  console.log("Fetch single Entry");
  console.log("get id",req.query);
  User.find(req.query)
    .then(users => {
    res.send(users);
}).catch(err => {
    res.status(500).send({
    message: err.message
  });
});
};
exports.delete = (req , res) =>  {
  console.log("Fetch single Entry");
  console.log("get id",req.query);
  User.deleteOne(req.query)
    .then(users => {
    res.send(users);
}).catch(err => {
    res.status(500).send({
    message: err.message
  });
});
};
exports.update = (req, res) =>  {
  console.log('Post a User: ' ,req.body);
  console.log('id: ' ,req.query);
  // Create a Customer

  User.updateOne(req.body)
    .then(data => {
    res.send(data);
}).catch(err => {
    res.status(500).send({
    message: err.message
  });
});
};