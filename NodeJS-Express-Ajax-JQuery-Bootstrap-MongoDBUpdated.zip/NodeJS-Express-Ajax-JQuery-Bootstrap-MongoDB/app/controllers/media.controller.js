var Media = require('../models/media.model.js');
 
// Save media - User to MongoDB
exports.imageSave = (req , res) => {
	console.log('Post a Media:');
	console.log('Post a Media: ' + JSON.stringify(req));

    // Create a Customer
    const media = new Media({
    uId: req.body.uId,
		image: {
      src:  req.body.image.src,
      name: req.body.image.name
    }
    });
    console.log("data media",media);
    // Save a Customer in the MongoDB
  media.save()
    .then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            message: err.message
        });
    });
};
