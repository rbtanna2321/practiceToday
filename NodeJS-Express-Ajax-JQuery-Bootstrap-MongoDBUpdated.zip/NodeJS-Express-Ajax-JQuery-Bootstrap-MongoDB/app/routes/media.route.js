module.exports = function(app) {
 
	var express = require("express");
	var router = express.Router();
    const media = require('../controllers/media.controller.js');

	var path = __basedir + '/views/';

  router.use(function (req,res,next) {
    console.log("/media" + req.method);
    next();
  });

  app.get('/media', (req,res) => {
    res.sendFile(path + "media.html");
});
 

  // Save a User to MongoDB
  app.post('api/media/add', media.imageSave);

  app.use("/media",router);
 
	app.use("*", (req,res) => {
		res.sendFile(path + "404.html");
	});
}