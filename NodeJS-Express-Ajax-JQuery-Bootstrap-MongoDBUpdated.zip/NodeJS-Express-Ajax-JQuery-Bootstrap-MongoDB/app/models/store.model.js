var mongoose = require('mongoose'),
Schema = mongoose.Schema,
autopopulate = require('mongoose-autopopulate');

var StoreSchema = Schema({
  name: {type: String},
  description: {type: String},
  domain: {type: String},
  subdomain: String
});
StoreSchema.plugin(autopopulate);
module.exports = mongoose.model('Store', StoreSchema);