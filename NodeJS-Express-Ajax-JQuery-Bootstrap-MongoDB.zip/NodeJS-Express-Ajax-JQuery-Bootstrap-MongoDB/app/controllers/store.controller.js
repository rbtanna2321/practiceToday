var Store = require('../models/store.model.js');

exports.getStore = (req, res) =>  {
  console.log("Fetch all Store");
  Store.find()
    .then(store => {
    res.send(store);
}).catch(err => {
    res.status(500).send({
      message: err.message
    });
});
};
