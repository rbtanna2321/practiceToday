module.exports = function(app) {
 
	var express = require("express");
	var router = express.Router();
	
    var users = require('../controllers/user.controller.js');
    var stores = require('../controllers/store.controller.js');

	var path = __basedir + '/views/';


	app.get('/', (req,res) => {
		res.sendFile(path + "index.html")
	})

	app.get('/media', (req,res) => {
		res.sendFile(path + "media.html")
	})




    // Save a User to MongoDB
    app.post('/api/users/save', users.save);

    // Retrieve all Users
    app.get('/api/users/all', users.findAll);

    // Retrieve all Users
    app.get('/api/getStore', stores.getStore);

  // Retrieve edit Users
  app.get('/api/users/edit', users.edit);

  // Retrieve delete Users
  app.get('/api/users/delete', users.delete);

  // Retrieve Search Users
  app.get('/api/users/search', users.search);

  // Retrieve update Users
  app.post('/api/users/update', users.update);

	app.use("/",router);
	app.use("/media",router);
 
	app.use("*", (req,res) => {
		res.sendFile(path + "404.html");
	});
}