var mongoose = require('mongoose');

var MediaSchema = mongoose.Schema({
  uId: Number,
  image: {
    src:  String,
    name: String
  }
});

module.exports = mongoose.model('Media', MediaSchema);