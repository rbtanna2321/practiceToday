var mongoose = require('mongoose'),
  Schema = mongoose.Schema,
  autopopulate = require('mongoose-autopopulate');

var UserSchema = Schema({
  uId: Number,
  image: {
    src: String,
    name: String
  },
  store: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Store'
  },
  username: String,
  gender: String,
  hobby: Array,
  city: String
});
UserSchema.plugin(autopopulate);
module.exports = mongoose.model('User', UserSchema);