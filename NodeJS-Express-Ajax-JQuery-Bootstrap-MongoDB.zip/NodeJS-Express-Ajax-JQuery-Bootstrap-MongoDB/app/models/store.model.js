var mongoose = require('mongoose'),
Schema = mongoose.Schema,
autopopulate = require('mongoose-autopopulate');

var StoreSchema = Schema({
  name:  String,
  description:  String,
  domain:  String,
  subdomain: String
});
StoreSchema.plugin(autopopulate);
module.exports = mongoose.model('Store', StoreSchema);